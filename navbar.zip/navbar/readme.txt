npm init
npm install --save express ejs
